
import java.util.Random;
import java.util.Scanner;
public class JankenPoGame{
		  public static void main(String[]args){

		    Scanner scanner = new Scanner(System.in);

		    //creating the user option to input

		    System.out.println("手を選んでください。(ぐー/チョキ/パー)");
		    String playerMove = scanner.nextLine();
		   System.out.println("あなたは" +playerMove+ "です。");

		    //generating the random number
		    Random random = new Random();
		    int randomN = random.nextInt(3);

		    String computerMove;
		    if(randomN == 0){
		      computerMove = "ぐー";
		    }else if(randomN == 1){
		      computerMove = "チョキ";
		    }else {
		      computerMove = "パー";
		    }
		    System.out.println("あいては "+ computerMove +"です。");

		    //comparing the move

		    if (playerMove.equals(computerMove)){
		      System.out.println("あいこです。.");
		    }else if (playerWins(playerMove,computerMove)){
		      System.out.println("あなたはかちです。");
		    }else {
		      System.out.println("あいての勝ちです。");
		    }

		  }

		  //creating method to compare the both player move and result

		  static boolean playerWins(String playerMove,String computerMove){

		    if(playerMove.equals("ぐー")){
		      return computerMove.equals("パー");
		    }else if(playerMove.equals("チョキ")){
		      return computerMove.equals("ぐー");
		    }else {
		      return computerMove.equals("チョキ");

		  }

		}
}
