package abc;

import java.util.Scanner;


public class abcd {
	static Osero[] osero = new Osero[64];

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		Scanner scanner = new Scanner(System.in);
        for(int i= 0; i < 64;i++) {
            osero[i] = new Osero();
        }

        disp();

        int osero_count=0;
        int osero_x;
        int osero_y;
    
		do {
            System.out.print("どこ（よこ1～8 + たて 10～80）におく？＝");
            int osero_number = scanner.nextInt();

            osero_x = (osero_number % 10) - 1;
            osero_y = (osero_number / 10) - 1;

            if(osero_x < 0 || osero_x > 7 || osero_y < 0 || osero_y > 7) {
                    continue;
            }

            if(osero[osero_y * 8 + osero_x].getOsero_Status() != 0) {
                    continue;
            }

            osero[osero_y * 8 + osero_x].setOsero_Status(osero_count % 2 + 1);

            osero_count++;

            disp();

		}while(osero_count < 64);
		
	}

	static void disp() {
		for(int i = 0;i < 8;i++) {
            for(int j = 0;j < 8;j++) {
                    if(osero[i*8+j].getOsero_Status() == 0) {
                            System.out.print("□");
                    }else if(osero[i*8+j].getOsero_Status() == 1){
                            System.out.print("●");
                    }else if(osero[i*8+j].getOsero_Status() == 2){
                            System.out.print("〇");
                    }else {
                            System.out.print("");
                    }
            }
            System.out.println("");
		}
	}
}

class Osero{
	int osero_status;  //0: Non  1: Blank  2:White

	void setOsero_Status(int rs) {
		osero_status = rs;
	}
	int getOsero_Status() {
		return osero_status;

	}
}





