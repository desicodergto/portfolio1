package abc;

import java.util.Scanner;

public class project2 {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		Scanner s = new Scanner(System.in);
		int[] data = new int[10];
		int i;
		for(i=0;i<10;i++) {
			
			System.out.print("data[" + i + "]=");
			data [i] = s.nextInt();
		}

		sort(data);
		 for (i = 0;i<10;i++) {
			 System.out.println("data[" + i + "]="+ data[i]);
		
	}

}
private static void sort(int data[]) {
	//int deta[] is equal to above statemet int[] data = new int[10];
	 int n = data.length;
	 int temp ;
	 int i,j;
	 for(j=0;j<n-1;j++) {   //j<n-1
		 for(i=n-1;i>j;i--) {  //i=n-1
			 if(data[i-1]>data[i]) {  //data[i-1]
				 temp = data[i-1];
				 data[i-1] = data[i];
				 data[i]= temp;
			 	}
		 	}
	 	}
	}
}
