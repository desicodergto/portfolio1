
import  java.awt.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import javax.swing.*;

public class TicTacToe implements ActionListener{

	// for the first step we have to determine whose turn is randomly so we will create the random class
	
	Random random = new Random();
	JFrame frame = new JFrame();
	//JPanel pane = new JPanel();
	JPanel title_panel = new JPanel();
	JPanel button_panel = new JPanel();
	JLabel textfield = new JLabel();
	
	JButton[] buttons = new JButton[9]; // creating the array of jButton 
	boolean player1_turn;
	
	
	
	
	TicTacToe(){
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800,800);
		frame.getContentPane().setBackground(new Color(50,50,50)); // set generic type color or rgb
		frame.setLayout(new BorderLayout());
		
		
		
		// setting the background color to textfield
		
		textfield.setBackground(new Color(25,25,25) );
		textfield.setForeground(new Color(25,255,0));
		textfield.setFont(new Font("Ink Free", Font.BOLD,75));
		textfield.setHorizontalAlignment(JLabel.CENTER);
		textfield.setText("TicTacToe");
		textfield.setOpaque(true);
		
		
		// title_panel    
		
		title_panel.setLayout(new BorderLayout());
		title_panel.setBounds(0, 0, 800, 100);
		
		// adding the button using the for loop
		
		button_panel.setLayout(new GridLayout(3,3));
		button_panel.setBackground(new Color(150,150,150));
		
		
		for (int i = 0; i<9; i++) {
			
			buttons[i] = new JButton();
			button_panel.add(buttons[i]);
			buttons[i].setFont(new Font("MV Boli",Font.BOLD,120));
			buttons[i].setFocusable(false);
			buttons[i].addActionListener(this);
			
		}
		
		// adding the title_panel to frame
		
		
		title_panel.add(textfield);
		frame.add(title_panel,BorderLayout.NORTH);
		frame.add(button_panel);
		frame.setVisible(true);
		
		firstTurn(); // calling the first turn method
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		for (int i = 0 ; i< 9; i++) {
			if (e.getSource()== buttons[i]) {
				if(player1_turn) {
					if(buttons[i].getText()== "") {
						buttons[i].setForeground(new Color(255,0,90));
						buttons[i].setText("X");
						player1_turn = false;
						textfield.setText("o-turns");
						check(); // calling the check() method
					}
				}
				else {
					if(buttons[i].getText()== "") {
						buttons[i].setForeground(new Color(0,0,255));
						buttons[i].setText("O");
						player1_turn = true;
						textfield.setText("X-turns");
						check();  // calling the check() method
					}
				}
			}
		}	
	}
	
	
	// creating the method for the separate for x turn and y turn
	
	public void firstTurn() {
		
		// we can also use the delay function and Thread.sleep(); 
		
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// there are some few ways to the this but here we will use the random class to generate the 0 and 1
		// 0 - x turn and 1- o turn
		
		if (random.nextInt(2) == 0) {
			player1_turn = true;
			textfield.setText("x turn");
		}
		else {
			player1_turn = false;
			textfield.setText("o-turn");
		}
	}
	
	// creating the method to check the any player is winning 
	
	public void check() {
		
		// checking the x win condition 
		
		if(
				(buttons[0].getText()=="X") &&
				(buttons[1].getText()=="X") &&
				(buttons[2].getText()=="X")
				) {
			xWins(0,1,2);
		}
		
		if(
				(buttons[3].getText()=="X") &&
				(buttons[4].getText()=="X") &&
				(buttons[5].getText()=="X")
				) {
			xWins(3,4,5);
		}
		
		if(
				(buttons[6].getText()=="X") &&
				(buttons[7].getText()=="X") &&
				(buttons[8].getText()=="X")
				) {
			xWins(6,7,8);
		}
		
		if(
				(buttons[0].getText()=="X") &&
				(buttons[3].getText()=="X") &&
				(buttons[6].getText()=="X")
				) {
			xWins(0,3,6);
			
		}
		if(
				(buttons[1].getText()=="X") &&
				(buttons[4].getText()=="X") &&
				(buttons[7].getText()=="X")
				) {
			xWins(1,4,7);
			
		}
		if(
				(buttons[2].getText()=="X") &&
				(buttons[5].getText()=="X") &&
				(buttons[8].getText()=="X")
				) {
			xWins(2,5,8);
			
		}
		if(
				(buttons[0].getText()=="X") &&
				(buttons[4].getText()=="X") &&
				(buttons[8].getText()=="X")
				) {
			xWins(0,4,8);
			
		}
		if(
				(buttons[2].getText()=="X") &&
				(buttons[4].getText()=="X") &&
				(buttons[6].getText()=="X")
				) {
			xWins(2,4,6);
			
		}
		
		// checking the 0 win condition
		
		if(
				(buttons[0].getText()=="O") &&
				(buttons[1].getText()=="O") &&
				(buttons[2].getText()=="O")
				) {
			oWins(0,1,2);
		}
		
		if(
				(buttons[3].getText()=="O") &&
				(buttons[4].getText()=="O") &&
				(buttons[5].getText()=="O")
				) {
			oWins(3,4,5);
		}
		
		if(
				(buttons[6].getText()=="O") &&
				(buttons[7].getText()=="O") &&
				(buttons[8].getText()=="O")
				) {
			oWins(6,7,8);
		}
		
		if(
				(buttons[0].getText()=="O") &&
				(buttons[3].getText()=="O") &&
				(buttons[6].getText()=="O")
				) {
			oWins(0,3,6);
			
		}
		if(
				(buttons[1].getText()=="O") &&
				(buttons[4].getText()=="O") &&
				(buttons[7].getText()=="O")
				) {
			oWins(1,4,7);
			
		}
		if(
				(buttons[2].getText()=="O") &&
				(buttons[5].getText()=="O") &&
				(buttons[8].getText()=="O")
				) {
			oWins(2,5,8);
			
		}
		if(
				(buttons[0].getText()=="O") &&
				(buttons[4].getText()=="O") &&
				(buttons[8].getText()=="O")
				) {
			oWins(0,4,8);
			
		}
		if(
				(buttons[2].getText()=="O") &&
				(buttons[4].getText()=="O") &&
				(buttons[6].getText()=="O")
				) {
			oWins(2,4,6);
			
		}
		
	}
	
	// creating the two method for x and o , winning and then it will check to the check() method 
	
	public void xWins(int a , int b , int c ) {
		
		buttons[a].setBackground(new Color(0, 255, 0));
		buttons[b].setBackground(new Color(0, 255, 0));
		buttons[c].setBackground(new Color(0, 255, 0));
		
		for(int i = 0; i<9 ; i++) {
			buttons[i].setEnabled(false);
		}
		textfield.setText(" X wins");
	}
	
	public void oWins(int d , int e , int f ) {
		
		buttons[d].setBackground(new Color(0, 255, 0));
		buttons[e].setBackground(new Color(0, 255, 0));
		buttons[f].setBackground(new Color(0, 255, 0));
		
		for(int i = 0; i<9 ; i++) {
			buttons[i].setEnabled(false);
		}
		textfield.setText(" O wins");
	}
}
