
public class Main {

	public static void main(String[] args) {
		
		//MouseListener = 
		// for mouse listener interface = there are five option 
		new MyFrame();

	}

}
