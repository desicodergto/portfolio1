import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.*;

import javax.swing.JFrame;

public class MyFrame extends JFrame implements MouseListener {
	
	JLabel label;
	ImageIcon smile;
	ImageIcon nervous;
	ImageIcon pain;
	ImageIcon dizzy;
	ImageIcon cool;
	
	MyFrame(){
		
		// to have some good demo lets create the label and then we apply the mouse listener to it 
		// what if we apply the MouseListener to JFrame in stead of label 
		// it really effect all the thing when we apply listener to frame and its make big difference and have thing where to apply as well 
		
		// small project we will apply the icon to label or frame and change it with our mouse 
		
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(500,500);
		this.setLayout(new FlowLayout());
		
		label =  new JLabel();
		label.addMouseListener(this);
		
		//label.setBounds(1,0,100,100);
		//label.setBackground(Color.RED);
		//label.setOpaque(true);
		
		// creating the icon and we will add to frame 
		smile  = new ImageIcon("smile.png");
		nervous  = new ImageIcon("nervous.png");
		pain  = new ImageIcon("pain.png");
		dizzy  = new ImageIcon("dizzy.png");
		cool = new ImageIcon("cool.png");
		
		label.setIcon(smile);

		this.addMouseListener(this); // this will respond when we hover on the frame lets see the result  
		this.add(label);
		this.pack();
		this.setLocationRelativeTo(null); // frame will appear the frame to pop out at middle of screen 
		this.setVisible(true);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		 // Invoked when the mouse button has been clicked (pressed and released ) on a component 
		//it will only work when we clicked to label because we only apply the mouse lister to label 
		
		//System.out.println("You clicked the mouse.");
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// Invoked when a mouse button has been pressed on a component
		// any button you press the outline will produced
		// for more , lets change the label color when we pressed the component
		
		//label.setBackground(Color.yellow); // set the color to background 
		label.setIcon(pain);
		System.out.println("You pressed the mouse. It hurts ");
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		//Invoked when a mouse button has been released on a component
		//this will only invoked when we released the mouse lets see the result
		
		
		//label.setBackground(Color.blue);
		label.setIcon(dizzy);
		System.out.println("You released the mouse. I am dizzy ");
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// Invoked when the mouse enters a component
		//label.setBackground(Color.green);
		
		label.setIcon(nervous);
		System.out.println("You entered the component. I am nervous ");
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// Invoked when the mouse exits a component
		//label.setBackground(Color.red);
		
		label.setIcon(cool);
		System.out.println("You exit the component. turn cool , thank you! ");
		
	}

}
