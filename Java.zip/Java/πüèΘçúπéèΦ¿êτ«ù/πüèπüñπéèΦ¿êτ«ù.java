package rensyumondai;

import java.util.Scanner;

public class Otsurikeisan {
	public static void main(String[] args){
		int kingaku = 0;

		Scanner stdIn = new Scanner(System.in);

		do{
			System.out.print("金額を入力してください。：");
			kingaku = stdIn.nextInt();
		}while(kingaku <= 0);

		System.out.println("1万円札は・・・" + (kingaku / 10000) + "枚です。");
		kingaku %= 10000;

		System.out.println("5千円札は・・・" + (kingaku / 5000) + "枚です。");
		kingaku %= 5000;

		System.out.println("2千円札は・・・" + (kingaku / 2000) + "枚です。");
		kingaku %= 2000;

		System.out.println("千円札は・・・" + (kingaku / 1000) + "枚です。");
		kingaku %= 1000;

		System.out.println("5百円は・・・" + (kingaku / 500) + "枚です。");
		kingaku %= 500;

		System.out.println("百円は・・・" + (kingaku / 100) + "枚です。");
		kingaku %= 100;

		System.out.println("5十円は・・・" + (kingaku / 50) + "枚です。");
		kingaku %= 50;

		System.out.println("十円は・・・" + (kingaku / 10) + "枚です。");
		kingaku %= 10;

		System.out.println("五円は・・・" + (kingaku / 5) + "枚です。");
		kingaku %= 5;

		System.out.println("一円は・・・" + (kingaku / 1) + "枚です。");
	}
}
